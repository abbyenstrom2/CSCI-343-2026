import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StyleSheet, Text, View, ScrollView, FlatList} from 'react-native';
import Restaurant from './components/Restaurant';

export default function App() {
const [restaurantItems, setRestaurantItems] = useState([
    {
      name: "Avenger's Endgame",
      image: require("./assets/images/Endgame.jpeg"),
      rating: "8.7",
    },
    {
      name: "Greatest Showman",
      image: require("./assets/images/Greatest-Showman.jpg"),
      rating: "8.5",
    },
    {
      name: "Hidden Figures",
      image: require("./assets/images/hiddenfigures.jpeg"),
      rating: "8",
    },
    {
      name: "How to Lose a Guy in 10 Days",
      image: require("./assets/images/howtoloseaguyin10days.jpeg"),
      rating: "7.5",
    },
    {
      name: "Interstellar",
      image: require("./assets/images/interstellar.jpeg"),
      rating: "8.8",
    },
    {
      name: "Rocky",
      image: require("./assets/images/rocky.jpg"),
      rating: "9.2",
    },
    {
      name: "Shawshank Redemption",
      image: require("./assets/images/shawshank.jpeg"),
      rating: "7.4",
    },
    {
      name: "Ten Things I Hate About You",
      image: require("./assets/images/tenthingsihateaboutyou.jpeg"),
      rating: "9",
    },
    {
      name: "Whats Eating Gilbert Grape",
      image: require("./assets/images/whatseatinggilbertgrape.jpeg"),
      rating: "7",
    },
    {
      name: "Wolf of Wall Street",
      image: require("./assets/images/wolfofwallstreet.jpeg"),
      rating: "7.1",
    },
  ]);
  return (
    <>
    <StatusBar style="dark" />
    <SafeAreaView style={styles.rootContainer}>
      <View style={styles.titleContainer}>
        <Text style={styles.title}>Top 10 Movies</Text>
      </View>
      <View style={styles.listContainer}>
         <FlatList
         alwaysBounceVertical={false}
         data={restaurantItems}
         keyExtractor={(item, index) => item.id}
         renderItem={(itemData) => {
          return (
            <Restaurant
              name={itemData.item.name}
              image={itemData.item.image}
              rating={itemData.item.rating}
            />

          );
         }}
        />
      </View>
    </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  rootContainer: {
    flex: 1,
    backgroundColor: '#1a16d5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleContainer: {
    justifyContent: 'center',
    marginBottom: 20,
    paddingHorizontal: 5,
    borderWidth: 5,
    borderRadius: 10,
    marginTop: 50
  },
  title: {
    fontSize: 35,
    fontWeight: 'bold'
  },
  listContainer: {
    flex: 8,
    width: "90%"
  },

});
