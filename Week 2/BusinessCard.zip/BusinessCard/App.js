import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, Linking} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
export default function App() {
  return (
    <>
      <StatusBar style="dark" />
      <SafeAreaView style={styles.root}>
        <View style={styles.imageContainer}>
          <Image
            style={styles.image}
            source={require("./assets/images/BusinessCardImage.jpg")}
          />
        </View>
        <View style={styles.textContainer}>
          <Text style={styles.name}>Abby Enstrom</Text>
          <Text style={styles.text}
          onPress={() => {
            Linking.openURL('mailto:apenstrom@coastal.edu')}}
          >apenstrom@coastal.edu</Text>
          <Text style={styles.text}
          onPress={() => {
            Linking.openURL('tel:484-895-9544');
          }}
          >
            484-895-9544
          </Text>
          <Text style={styles.text}
          onPress={() => {
            Linking.openURL("https://github.com/abbyenstrom2/CSCI-343-2026.git")}}
            >Open in GitHub</Text>
        </View>
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fa3456",
  },
  imageContainer: {
    flex: 2,
    justifyContent: "center",
    backgroundColor: "#020267",
    marginTop: 80,
    width: "100%",
  },
  image: {
    height: 300,
    width: "100%",
    resizeMode: "cover",
    borderColor: "black",
    borderWidth: 5
  },
  textContainer: {
    flex: 2,
    backgroundColor: "white",
    width: "100%",
    alignItems: "center",
  },
  name: {
    fontSize: 50,
    textAlign: "center",
    color: "#fa3456",
    fontWeight: "bold",
    marginBottom: 60
  },
  text: {
    fontSize: 25, 
    color: "#fa3456",
    fontStyle: "italic",
    marginBottom: 15

  }
});

