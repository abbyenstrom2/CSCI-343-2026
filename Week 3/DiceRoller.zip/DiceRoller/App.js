import { StatusBar } from 'expo-status-bar';
import {
  Button,
  Pressable,
  StyleSheet,
  Text,
  View,
  Modal,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useState } from 'react';

export default function App() {
  // Set max and min dice values
  const maxVal = 6;
  const minVal = 1;

  // Create State management variables
  const [dice1, setDice1] = useState(1);
  const [dice2, setDice2] = useState(1);
  const [userGuess, setUserGuess] = useState('');
  const [userWager, setUserWager] = useState('');
  const [diceSum, setDiceSum] = useState(2);
  const [modalIsVisible, setModalIsVisible] = useState(false);

  let resultText = (
    <Text style={styles.resultText}>Roll the Dice and Make a Wager</Text>
  );

  const userGuessNum = parseInt(userGuess);
  const diceSumNum = parseInt(diceSum);

  if (userGuess !== '' && userGuessNum === diceSumNum) {
    resultText = (
      <Text style={styles.resultText}>
        You Won ${(userWager * 5).toFixed(2)}
      </Text>
    );
  }

  if (userGuess !== '' && userGuessNum !== diceSumNum) {
    resultText = (
      <Text style={styles.resultText}>
        You Lost ${userWager.toFixed(2)}
      </Text>
    );
  }

  // Close the modal
  const endDiceRollHandler = () => {
    setModalIsVisible(false);
  };

  // Open the modal
  const startDiceRollHandler = () => {
    setUserGuess('');
    setUserWager('');
    setModalIsVisible(true);
  };

  // Roll the dice
  const onDiceRoll = () => {
    const newDice1 =
      Math.floor(Math.random() * (maxVal - minVal + 1)) + minVal;

    const newDice2 =
      Math.floor(Math.random() * (maxVal - minVal + 1)) + minVal;

    setDice1(newDice1);
    setDice2(newDice2);
    setDiceSum(newDice1 + newDice2);

    setModalIsVisible(false);
  };

  return (
    <>
      <StatusBar style="auto" />

      <SafeAreaView style={styles.root}>

        <View style={styles.titleContainer}>
          <Text style={styles.title}>Dice Roller</Text>
        </View>

        <View style={styles.rollButtonContainer}>
          <Pressable
            android_ripple={{ color: '#6935ad' }}
            onPress={startDiceRollHandler}
            style={({ pressed }) =>
              pressed && styles.pressedButton
            }
          >
            <View style={styles.rollButton}>
              <Text style={styles.rollButtonText}>
                Roll Dice
              </Text>
            </View>
          </Pressable>
        </View>

        <View style={styles.diceContainer}>

          <View style={styles.dice}>
            <Text style={styles.diceNumber}>
              {dice1}
            </Text>
          </View>

          <View style={styles.dice}>
            <Text style={styles.diceNumber}>
              {dice2}
            </Text>
          </View>

        </View>

        <View style={styles.resultContainer}>
          {resultText}
        </View>

        {/* Modal */}
        <Modal
          visible={modalIsVisible}
          animationType="slide"
        >
          <SafeAreaView style={styles.modalContainer}>

            <Text style={styles.modalTitle}>
              Make Your Guess
            </Text>

            <TextInput
              style={styles.input}
              placeholder="Enter dice sum (2-12)"
              onChangeText={setUserGuess}
              value={userGuess}
              keyboardType="number-pad"
            />

            <TextInput
              style={styles.input}
              placeholder="Enter wager"
              onChangeText={setUserWager}
              value={userWager}
              keyboardType="number-pad"
            />

            <View style={styles.modalButtonContainer}>
              <Button
                title="Roll Dice"
                onPress={onDiceRoll}
              />

              <Button
                title="Cancel"
                onPress={endDiceRollHandler}
              />
            </View>

          </SafeAreaView>
        </Modal>

      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#b52794',
    alignItems: 'center',
    justifyContent: 'center',
  },

  titleContainer: {
    flex: 1,
    backgroundColor: 'black',
    width: '90%',
    justifyContent: 'center',
    margin: 20,
    borderColor: 'white',
    borderWidth: 3,
    borderRadius: 30,
    marginTop: 50,
  },

  title: {
    fontSize: 40,
    color: 'white',
    textAlign: 'center',
  },

  rollButtonContainer: {
    flex: 1,
    justifyContent: 'center',
  },

  rollButton: {
    backgroundColor: 'white',
    borderRadius: 50,
    padding: 10,
  },

  rollButtonText: {
    color: 'black',
    padding: 8,
    fontSize: 25,
    textAlign: 'center',
    fontWeight: 'bold',
  },

  pressedButton: {
    opacity: 0.5,
  },

  diceContainer: {
    flex: 3,
    flexDirection: 'row',
    alignContent: 'space-between',
    justifyContent: 'center',
    alignItems: 'center',
    width: '80%',
  },

  dice: {
    borderWidth: 6,
    margin: 20,
    width: '40%',
    paddingVertical: 30,
    backgroundColor: 'white',
  },

  diceNumber: {
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
  },

  resultContainer: {
    flex: 1,
  },

  resultText: {
    fontSize: 25,
    color: 'white',
    textAlign: 'center',
  },

  modalContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },

  modalTitle: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 30,
  },

  input: {
    width: '80%',
    borderWidth: 2,
    borderColor: 'black',
    padding: 12,
    margin: 10,
    fontSize: 18,
  },

  modalButtonContainer: {
    flexDirection: 'row',
    gap: 20,
    marginTop: 20,
  },
});